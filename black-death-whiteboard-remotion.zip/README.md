# Black Death — Whiteboard Explainer (Remotion)

- Composition: `BlackDeath`
- Canvas: 720x1280 (9:16)
- FPS: 24
- Duration: 1217 frames / 50.72 seconds
- Audio: `public/narration.wav` (user-provided)

## Render locally
```bash
npm install
npx remotion render src/index.ts BlackDeath out/black-death.mp4
```

## Render on GitHub Actions
1. Create a new GitHub repository and upload/push this folder.
2. Open **Actions** and run **Render Black Death Explainer** (or push to `main`).
3. Download the `black-death-video` artifact from the completed workflow.

## Visual direction
Whiteboard look, marker-line illustrations, red/blue accents, gentle camera push/pan, scene fades, animated progress line, and original narration. Illustrations are vector drawings authored in the project; no external image assets required.

The scene timing is aligned to the supplied 50.72-second audio. For frame-exact output length, the composition uses 1217 frames at 24 fps (50.7083 seconds); Remotion frame durations are integer-based.
