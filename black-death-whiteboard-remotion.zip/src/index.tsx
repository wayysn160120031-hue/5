
import React from "react";
import {Composition, registerRoot, Sequence, useCurrentFrame, useVideoConfig, interpolate, spring, Audio, staticFile} from "remotion";

const INK="#20252b", RED="#c83b36", BLUE="#367a9e", GOLD="#d79b32";
const scenes=[
 {start:0,end:7.1,title:"BLACK DEATH",sub:"1347 — 1351",kind:"skull"},
 {start:7.1,end:15.0,title:"WABAH MENYEBAR",sub:"Jalur perdagangan & kapal",kind:"ship"},
 {start:15.0,end:22.5,title:"YERSINIA PESTIS",sub:"Bakteri • kutu terinfeksi",kind:"bacteria"},
 {start:22.5,end:32.0,title:"EROPA TERGUNCANG",sub:"Kota sepi • keluarga kehilangan",kind:"city"},
 {start:32.0,end:41.0,title:"TANPA OBAT MEMADAI",sub:"Jutaan nyawa melayang",kind:"empty"},
 {start:41.0,end:50.72,title:"JEJAK SEJARAH",sub:"Salah satu pandemi paling mematikan",kind:"legacy"}
];
const pathStyle={fill:"none",stroke:INK,strokeWidth:7,strokeLinecap:"round" as const,strokeLinejoin:"round" as const};
const line=(x1:number,y1:number,x2:number,y2:number,color=INK,w=7)=><line x1={x1} y1={y1} x2={x2} y2={y2} stroke={color} strokeWidth={w} strokeLinecap="round"/>;
const circle=(cx:number,cy:number,r:number,color=INK,w=7)=><circle cx={cx} cy={cy} r={r} fill="none" stroke={color} strokeWidth={w}/>;

const Drawing:React.FC<{kind:string; p:number}> = ({kind,p}) => {
 const dash=280, off=interpolate(p,[0,0.8],[dash,0],{extrapolateRight:"clamp"});
 const anim={strokeDasharray:dash,strokeDashoffset:off};
 return <svg viewBox="0 0 620 430" width="100%" height="100%" style={{overflow:"visible"}}>
 <g fill="none" strokeLinecap="round" strokeLinejoin="round" strokeWidth="8" stroke={INK}>
 {kind==="skull" && <>
   <path d="M170 200 C150 65 260 25 330 55 C430 95 455 205 390 270 L380 335 L220 335 L210 270 C180 250 165 225 170 200Z" style={anim}/>
   <path d="M220 195 Q260 145 295 195 Q260 240 220 195Z" stroke={RED}/><path d="M330 195 Q370 145 405 195 Q370 240 330 195Z" stroke={RED}/>
   <path d="M310 230 L285 275 L330 275Z" stroke={RED}/>{[250,285,320,355].map(x=>line(x,310,x,340))}
   <path d="M105 90 L145 120 M450 90 L485 55 M455 315 L500 350" stroke={GOLD}/>
 </>}
 {kind==="ship" && <>
  <path d="M95 285 Q300 355 525 285 L475 365 L165 365Z" style={anim}/>
  <path d="M300 80 L300 285 M300 100 L445 250 L300 250Z M280 130 L160 250 L280 250Z" stroke={BLUE}/>
  <path d="M80 390 Q130 365 180 390 T280 390 T380 390 T480 390 T580 390" stroke={BLUE}/>
  <path d="M95 120 Q130 90 165 120 M455 90 Q490 60 525 90" stroke={GOLD}/>
 </>}
 {kind==="bacteria" && <>
  {circle(310,215,115,RED,10)}{circle(275,185,16,RED,5)}{circle(350,245,12,RED,5)}{circle(330,160,9,RED,5)}
  {Array.from({length:12},(_,i)=>{const a=i*Math.PI/6;return <g key={i}>{line(310+115*Math.cos(a),215+115*Math.sin(a),310+150*Math.cos(a),215+150*Math.sin(a),RED,6)}{circle(310+160*Math.cos(a),215+160*Math.sin(a),6,RED,3)}</g>})}
  <path d="M80 85 Q150 30 210 90 Q250 130 210 165 Q165 195 130 160 Q95 125 80 85Z" stroke={INK}/>
  <path d="M130 95 L170 130 M170 95 L130 130" stroke={GOLD}/>
 </>}
 {kind==="city" && <>
  <path d="M80 345 L80 185 L160 125 L240 185 L240 345 M255 345 L255 155 L340 85 L425 155 L425 345 M440 345 L440 220 L520 165 L575 220 L575 345" style={anim}/>
  {Array.from({length:7},(_,i)=> <g key={i}>{line(105+i%3*48,220+Math.floor(i/3)*55,125+i%3*48,220+Math.floor(i/3)*55,BLUE,5)}</g>)}
  <path d="M60 365 L585 365" stroke={RED}/>
  <path d="M285 365 Q310 330 335 365 M300 335 L300 300 M330 335 L330 300" stroke={GOLD}/>
 </>}
 {kind==="empty" && <>
  <path d="M130 335 L130 130 L490 130 L490 335Z" style={anim}/>
  <path d="M180 335 L180 205 L275 205 L275 335 M345 335 L345 205 L440 205 L440 335" stroke={BLUE}/>
  <path d="M255 130 L255 65 L365 65 L365 130" stroke={RED}/>
  <path d="M285 95 L335 95 M310 70 L310 120" stroke={RED}/>
  <path d="M80 380 Q160 350 240 380 T400 380 T560 380" stroke={GOLD}/>
 </>}
 {kind==="legacy" && <>
  <path d="M310 70 L310 350 M170 135 L450 135 M210 135 L185 350 M410 135 L435 350 M150 350 L470 350" style={anim}/>
  <path d="M170 135 Q310 25 450 135" stroke={RED}/>
  <path d="M240 200 L285 245 L385 165" stroke={BLUE} strokeWidth="13"/>
  <path d="M115 390 L505 390" stroke={GOLD}/>
 </>}
 </g></svg>
};
const Scene:React.FC<{s:typeof scenes[number];index:number}> = ({s,index})=>{
 const f=useCurrentFrame(); const {fps}=useVideoConfig(); const local=f-Math.round(s.start*fps);
 const p=spring({frame:Math.max(0,local),fps,config:{damping:18,stiffness:75}});
 const zoom=interpolate(local,[0,(s.end-s.start)*fps],[1,1.13],{extrapolateRight:"clamp"});
 const fade=interpolate(local,[0,10, (s.end-s.start)*fps-10,(s.end-s.start)*fps],[0,1,1,0],{extrapolateRight:"clamp"});
 return <div style={{position:"absolute",inset:0,background:"#fbfaf5",opacity:fade,overflow:"hidden"}}>
  <div style={{position:"absolute",inset:30,border:"3px solid #e8e3d7",borderRadius:22}}/>
  <div style={{position:"absolute",top:72,left:48,right:48,textAlign:"center",fontFamily:"Arial,sans-serif",fontWeight:900,fontSize:46,letterSpacing:2,color:INK,transform:`translateY(${(1-p)*25}px)`}}>{s.title}</div>
  <div style={{position:"absolute",top:145,left:45,right:45,textAlign:"center",fontFamily:"Arial,sans-serif",fontSize:25,color:RED,fontWeight:700}}>{s.sub}</div>
  <div style={{position:"absolute",top:260,left:35,right:35,height:440,transform:`scale(${zoom}) translate(${Math.sin(local/24)*5}px,${Math.cos(local/31)*4}px)`}}>
   <Drawing kind={s.kind} p={p}/>
  </div>
  <div style={{position:"absolute",bottom:90,left:50,right:50,height:7,background:"#e7e0d3",borderRadius:9}}>
   <div style={{height:"100%",width:`${Math.max(0,Math.min(100,(local/((s.end-s.start)*fps))*100))}%`,background:RED,borderRadius:9}}/>
  </div>
  <div style={{position:"absolute",bottom:48,left:0,right:0,textAlign:"center",fontSize:17,letterSpacing:4,color:"#777",fontFamily:"Arial"}}>SEJARAH DALAM 60 DETIK</div>
  <div style={{position:"absolute",top:25,right:38,fontSize:17,color:"#777",fontFamily:"Arial"}}>0{index+1} / 06</div>
 </div>
};
const Main:React.FC=()=>{
 const f=useCurrentFrame(); const {fps}=useVideoConfig();
 return <div style={{flex:1,background:"#fbfaf5",position:"relative"}}>
  <Audio src={staticFile("narration.wav")} volume={1}/>
  {scenes.map((s,i)=><Sequence key={i} from={Math.round(s.start*fps)} durationInFrames={Math.round((s.end-s.start)*fps)}>
    <Scene s={s} index={i}/>
  </Sequence>)}
  <div style={{position:"absolute",inset:0,pointerEvents:"none",boxShadow:"inset 0 0 100px rgba(60,45,20,.12)"}}/>
 </div>
};
const Root:React.FC=()=> <Composition id="BlackDeath" component={Main} durationInFrames={1217} fps={24} width={720} height={1280}/>;
registerRoot(()=> <Root/>);
